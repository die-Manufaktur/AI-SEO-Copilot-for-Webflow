// workers/index.ts
import OpenAI from "openai";
import { WebflowClient } from "webflow-api";
import * as ip from "ip";
import IPCIDR from "ip-cidr";
import { URL } from "url";
import { JSDOM } from "jsdom";
var allowedOrigins = [
  "https://webflow.com",
  "https://*.webflow-ext.com",
  "https://*.webflow.io",
  "http://localhost:1337",
  // For local development
  "http://localhost:5173"
  // For Vite development server
];
var createDomainPattern = (domain) => {
  const escapeRegExp2 = (str) => {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  };
  if (domain.includes("*")) {
    const parts = domain.split("*.");
    if (parts.length === 2) {
      const escapedDomain = escapeRegExp2(parts[1]);
      return new RegExp("^([a-zA-Z0-9][-a-zA-Z0-9]*\\.)" + escapedDomain + "$");
    }
  }
  return new RegExp("^" + escapeRegExp2(domain) + "$");
};
var originPatterns = allowedOrigins.map(createDomainPattern);
var isAllowedOrigin = (origin) => {
  if (!origin)
    return false;
  return originPatterns.some((pattern) => pattern.test(origin));
};
var handleCors = (request) => {
  const origin = request.headers.get("Origin");
  if (!origin || !isAllowedOrigin(origin)) {
    return new Response("Forbidden", { status: 403 });
  }
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Max-Age": "86400"
      }
    });
  }
  return null;
};
async function fetchOAuthToken(code, env) {
  const clientId = env.WEBFLOW_CLIENT_ID;
  const clientSecret = env.WEBFLOW_CLIENT_SECRET;
  const redirectUri = env.WEBFLOW_REDIRECT_URI;
  const response = await fetch("https://api.webflow.com/oauth/access_token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      code,
      redirect_uri: redirectUri,
      grant_type: "authorization_code"
    })
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch OAuth token: ${response.statusText}`);
  }
  const data = await response.json();
  return data.access_token;
}
async function handleOAuthTokenExchange(request, env) {
  try {
    const { code } = await request.json();
    if (!code) {
      return new Response(JSON.stringify({ error: "Missing authorization code" }), { status: 400 });
    }
    const token = await fetchOAuthToken(code, env);
    return new Response(JSON.stringify({ token }), { status: 200 });
  } catch (error) {
    console.error("Error handling OAuth token exchange:", error);
    return new Response(JSON.stringify({ error: "Failed to exchange OAuth token" }), { status: 500 });
  }
}
async function handleAuthRedirect(request, env) {
  try {
    const authorizeUrl = WebflowClient.authorizeURL({
      state: env.STATE,
      scope: "sites:read",
      clientId: env.WEBFLOW_CLIENT_ID,
      redirectUri: env.WEBFLOW_REDIRECT_URI
    });
    return Response.redirect(authorizeUrl, 302);
  } catch (error) {
    console.error("Error creating authorization link:", error);
    return new Response(JSON.stringify({ error: "Failed to create authorization link" }), { status: 500 });
  }
}
async function handleAuthCallback(request, env) {
  try {
    const url = new URL(request.url);
    const code = url.searchParams.get("code");
    const state = url.searchParams.get("state");
    if (!code) {
      return new Response(JSON.stringify({ error: "Missing authorization code" }), { status: 400 });
    }
    if (state !== env.STATE) {
      return new Response(JSON.stringify({ error: "State does not match" }), { status: 400 });
    }
    const token = await fetchOAuthToken(code, env);
    await env.TOKENS.put("user-access-token", token);
    return new Response(JSON.stringify({ message: "Authorization code received", token }), { status: 200 });
  } catch (error) {
    console.error("Error handling auth callback:", error);
    return new Response(JSON.stringify({ error: "Failed to handle auth callback" }), { status: 500 });
  }
}
function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function isNextGenImageFormat(src) {
  if (!src)
    return false;
  const extension = src.split(".").pop()?.toLowerCase();
  return extension === "webp" || extension === "avif" || extension === "jxl" || extension === "heif" || extension === "heic";
}
function calculateKeyphraseDensity(content, keyphrase) {
  const normalizedContent = content.toLowerCase().trim();
  const normalizedKeyphrase = keyphrase.toLowerCase().trim();
  const escapedKeyphrase = escapeRegExp(normalizedKeyphrase);
  const totalWords = normalizedContent.split(/\s+/).filter((word) => word.length > 0).length;
  const regex = new RegExp(`\\b${escapedKeyphrase}\\b`, "gi");
  const matches = normalizedContent.match(regex) || [];
  const occurrences = matches.length;
  const density = occurrences * normalizedKeyphrase.split(/\s+/).length / totalWords * 100;
  return { density, occurrences, totalWords };
}
function isHomePage(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.pathname === "/" || urlObj.pathname === "";
  } catch {
    return false;
  }
}
var checkPriorities = {
  "Keyphrase in Title": "high",
  "Keyphrase in Meta Description": "high",
  "Keyphrase in URL": "medium",
  "Content Length on page": "high",
  // Updated name
  "Keyphrase Density": "medium",
  "Keyphrase in Introduction": "medium",
  "Keyphrase in H1 Heading": "high",
  "Keyphrase in H2 Headings": "medium",
  "Heading Hierarchy": "high",
  "Image Alt Attributes": "low",
  "Internal Links": "medium",
  "Outbound Links": "low",
  "Next-Gen Image Formats": "low",
  "OpenGraph Image": "medium",
  // Updated to OpenGraph instead of OG
  "Open Graph Title and Description": "medium",
  // Updated to match Home.tsx
  "Code Minification": "low",
  "Schema Markup": "medium",
  "Image File Size": "medium"
};
function getSuccessMessage(checkType, url) {
  const messages = {
    "Keyphrase in Title": "Great job! Your title includes the target keyphrase.",
    "Keyphrase in Meta Description": "Perfect! Your meta description effectively uses the keyphrase.",
    "Keyphrase in URL": isHomePage(url) ? "All good here, since it's the homepage! \u2728" : "Excellent! Your URL is SEO-friendly with the keyphrase.",
    "Content Length on page": "Well done! Your content length is good for SEO.",
    "Keyphrase Density": "Perfect! Your keyphrase density is within the optimal range.",
    "Keyphrase in Introduction": "Excellent! You've included the keyphrase in your introduction.",
    "Image Alt Attributes": "Well done! Your images are properly optimized with the keyphrase.",
    "Internal Links": "Perfect! You have a good number of internal links.",
    "Outbound Links": "Excellent! You've included relevant outbound links.",
    "Next-Gen Image Formats": "Excellent! Your images use modern, optimized formats.",
    "OpenGraph Image": "Great job! Your page has a properly configured OpenGraph image.",
    "Open Graph Title and Description": "Perfect! Open Graph title and description are well configured.",
    "Keyphrase in H1 Heading": "Excellent! Your main H1 heading effectively includes the keyphrase.",
    "Keyphrase in H2 Headings": "Great job! Your H2 subheadings include the keyphrase, reinforcing your topic focus.",
    "Heading Hierarchy": "Great job! Your page has a proper heading tag hierarchy.",
    "Code Minification": "Excellent! Your JavaScript and CSS files are properly minified for better performance.",
    "Schema Markup": "Great job! Your page has schema markup implemented, making it easier for search engines to understand your content.",
    "Image File Size": "Great job! All your images are well-optimized, keeping your page loading times fast."
  };
  return messages[checkType] || "Good job!";
}
var fallbackRecommendations = {
  "Keyphrase in Title": (keyphrase, title) => `Consider rewriting your title to include '${keyphrase}', preferably at the beginning. Here is a better title: "${keyphrase} - ${title}"`,
  "Keyphrase in Meta Description": (keyphrase, metaDescription) => `Add '${keyphrase}' to your meta description in a natural way that encourages clicks. Here is a better meta description: "${metaDescription ? metaDescription.substring(0, 50) : "Learn about"} ${keyphrase} ${metaDescription ? metaDescription.substring(50, 100) : "and discover how it can help you"}."`,
  "Keyphrase in Introduction": (keyphrase) => `Mention '${keyphrase}' in your first paragraph to establish relevance early.`,
  "Image Alt Attributes": (keyphrase) => `Add descriptive alt text containing '${keyphrase}' to at least one relevant image.`,
  "Internal Links": () => `Add links to other relevant pages on your site to improve navigation and SEO.`,
  "Outbound Links": () => `Link to reputable external sources to increase your content's credibility.`
};
function hasDangerousScheme(url) {
  const dangerous = ["javascript:", "data:", "vbscript:"];
  return dangerous.some((scheme) => url.toLowerCase().startsWith(scheme));
}
async function scrapeWebpage(url) {
  console.log(`Scraping webpage: ${url}`);
  try {
    if (hasDangerousScheme(url)) {
      throw new Error("URL uses a dangerous scheme");
    }
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = `https://${url}`;
    }
    const urlObj = new URL(url);
    if (hasDangerousScheme(urlObj.href)) {
      throw new Error("URL uses a dangerous scheme");
    }
    const response = await fetch(url);
    if (!response.ok)
      throw new Error(`Failed to fetch page: ${response.status} ${response.statusText}`);
    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;
    const baseUrl = new URL(url);
    const title = document.querySelector("title")?.textContent?.trim() || "";
    const metaDescription = document.querySelector('meta[name="description"]')?.getAttribute("content") || "";
    const ogMetadata = {
      title: document.querySelector('meta[property="og:title"]')?.getAttribute("content") || "",
      description: document.querySelector('meta[property="og:description"]')?.getAttribute("content") || "",
      image: document.querySelector('meta[property="og:image"]')?.getAttribute("content") || "",
      imageWidth: document.querySelector('meta[property="og:image:width"]')?.getAttribute("content") || "",
      imageHeight: document.querySelector('meta[property="og:image:height"]')?.getAttribute("content") || ""
    };
    const content = document.body.textContent?.trim() || "";
    const paragraphs = [];
    document.querySelectorAll("p").forEach((p) => {
      const text = p.textContent?.trim() || "";
      if (text)
        paragraphs.push(text);
    });
    const headings = [];
    for (let i = 1; i <= 6; i++) {
      document.querySelectorAll(`h${i}`).forEach((h) => {
        const text = h.textContent?.trim() || "";
        if (text)
          headings.push({ level: i, text });
      });
    }
    const images = [];
    document.querySelectorAll("img").forEach((img) => {
      const src = img.getAttribute("src") || "";
      const alt = img.getAttribute("alt") || "";
      if (src) {
        images.push({
          src,
          alt,
          isNextGen: isNextGenImageFormat(src)
        });
      }
    });
    const internalLinks = [];
    const outboundLinks = [];
    document.querySelectorAll("a[href]").forEach((a) => {
      const href = a.getAttribute("href");
      if (!href)
        return;
      if (href.startsWith("#") || hasDangerousScheme(href))
        return;
      try {
        const linkUrl = new URL(href, baseUrl.origin);
        if (linkUrl.hostname === baseUrl.hostname) {
          internalLinks.push(href);
        } else {
          outboundLinks.push(href);
        }
      } catch (e) {
      }
    });
    const resources = {
      js: [],
      css: []
    };
    document.querySelectorAll("script[src]").forEach((script) => {
      const scriptUrl = script.getAttribute("src");
      if (scriptUrl && !hasDangerousScheme(scriptUrl)) {
        try {
          let absoluteUrl = scriptUrl;
          if (scriptUrl.startsWith("//")) {
            absoluteUrl = `https:${scriptUrl}`;
          } else if (scriptUrl.startsWith("/")) {
            absoluteUrl = `${baseUrl.protocol}//${baseUrl.host}${scriptUrl}`;
          } else if (!scriptUrl.startsWith("http")) {
            absoluteUrl = new URL(scriptUrl, url).toString();
          }
          resources.js.push({
            url: absoluteUrl,
            minified: scriptUrl.includes(".min.js") || scriptUrl.includes("-min.js")
          });
        } catch (e) {
          console.log(`Error processing script URL: ${scriptUrl}`, e);
        }
      }
    });
    document.querySelectorAll("script:not([src])").forEach((script) => {
      const scriptContent = script.textContent?.trim();
      if (scriptContent && scriptContent.length > 0) {
        const isMinified2 = !scriptContent.includes("\n") && !/\s{2,}/.test(scriptContent) && scriptContent.length > 50;
        resources.js.push({
          url: "inline-script",
          minified: isMinified2
        });
      }
    });
    document.querySelectorAll("link[rel='stylesheet']").forEach((link) => {
      const cssUrl = link.getAttribute("href");
      if (cssUrl && !hasDangerousScheme(cssUrl)) {
        try {
          let absoluteUrl = cssUrl;
          if (cssUrl.startsWith("//")) {
            absoluteUrl = `https:${cssUrl}`;
          } else if (cssUrl.startsWith("/")) {
            absoluteUrl = `${baseUrl.protocol}//${baseUrl.host}${cssUrl}`;
          } else if (!cssUrl.startsWith("http")) {
            absoluteUrl = new URL(cssUrl, url).toString();
          }
          resources.css.push({
            url: absoluteUrl,
            minified: cssUrl.includes(".min.css") || cssUrl.includes("-min.css")
          });
        } catch (e) {
          console.log(`Error processing CSS URL: ${cssUrl}`, e);
        }
      }
    });
    document.querySelectorAll("style").forEach((style) => {
      const styleContent = style.textContent?.trim();
      if (styleContent && styleContent.length > 0) {
        const isMinified2 = !styleContent.includes("\n") && !/\s{2,}/.test(styleContent) && styleContent.length > 50;
        resources.css.push({
          url: "inline-style",
          minified: isMinified2
        });
      }
    });
    const schema = {
      detected: false,
      types: []
    };
    const schemaScripts = document.querySelectorAll('script[type="application/ld+json"]');
    if (schemaScripts.length > 0) {
      schema.detected = true;
      schemaScripts.forEach((script) => {
        try {
          const jsonData = JSON.parse(script.textContent || "{}");
          if (jsonData["@type"]) {
            if (Array.isArray(jsonData["@type"])) {
              jsonData["@type"].forEach((type) => {
                if (type && !schema.types.includes(type)) {
                  schema.types.push(type);
                }
              });
            } else {
              if (jsonData["@type"] && !schema.types.includes(jsonData["@type"])) {
                schema.types.push(jsonData["@type"]);
              }
            }
          } else if (Array.isArray(jsonData) && jsonData[0] && jsonData[0]["@type"]) {
            jsonData.forEach((item) => {
              if (item["@type"] && !schema.types.includes(item["@type"])) {
                schema.types.push(item["@type"]);
              }
            });
          }
        } catch (e) {
          console.log("Error parsing schema JSON:", e);
        }
      });
    }
    return {
      title,
      metaDescription,
      content,
      paragraphs,
      headings,
      images,
      internalLinks,
      outboundLinks,
      url,
      ogMetadata,
      resources,
      schema
    };
  } catch (error) {
    console.error(`Error scraping webpage: ${error.message}`);
    throw new Error(`Failed to scrape webpage: ${error.message}`);
  }
}
addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event.request, event.env));
});
async function handleRequest(request, env) {
  const corsResponse = handleCors(request);
  if (corsResponse)
    return corsResponse;
  const url = new URL(request.url);
  const path = url.pathname;
  const origin = request.headers.get("Origin");
  const corsHeaders = {
    "Access-Control-Allow-Origin": origin || "*",
    "Content-Type": "application/json"
  };
  console.log(`Handling request: ${request.method} ${path} from ${origin || "unknown origin"}`);
  if (path === "/api/analyze" && request.method === "HEAD") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  if (path === "/api/oauth/callback" && request.method === "POST") {
    return handleOAuthTokenExchange(request, env);
  }
  if (path === "/api/auth" && request.method === "GET") {
    return handleAuthRedirect(request, env);
  }
  if (path === "/api/callback" && request.method === "GET") {
    return handleAuthCallback(request, env);
  }
  try {
    if (path === "/api/analyze" && request.method === "POST") {
      const data = await request.json();
      const { keyphrase, url: url2 } = data;
      if (!keyphrase || !url2) {
        return new Response(JSON.stringify({ message: "Keyphrase and URL are required" }), { status: 400, headers: corsHeaders });
      }
      const results = await analyzeSEO(url2, keyphrase, env);
      return new Response(JSON.stringify(results), { status: 200, headers: corsHeaders });
    } else if (path === "/api/register-domains" && request.method === "POST") {
      const data = await request.json();
      const { domains } = data;
      if (!domains || !Array.isArray(domains)) {
        return new Response(JSON.stringify({ success: false, message: "Domains array is required" }), { status: 400, headers: corsHeaders });
      }
      return new Response(JSON.stringify({ success: true, message: `Successfully registered ${domains.length} domains.` }), { status: 200, headers: corsHeaders });
    } else if (path === "/api/ping" && (request.method === "GET" || request.method === "HEAD")) {
      const pingResponse = {
        status: "ok",
        message: "Worker is running",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      return new Response(JSON.stringify(pingResponse), {
        status: 200,
        headers: {
          ...corsHeaders,
          "Cache-Control": "public, max-age=60"
          // Cache for 60 seconds 
        }
      });
    }
    return new Response(JSON.stringify({ message: "Route not found", path }), { status: 404, headers: corsHeaders });
  } catch (error) {
    console.error("Error processing request:", error);
    return new Response(JSON.stringify({ message: "Internal server error", error: error.message }), { status: 500, headers: corsHeaders });
  }
}
var ALLOWED_DOMAINS = [
  "example.com",
  "pull-list.net",
  "*.pull-list.net",
  "www.pmds.pull-list.net",
  "pmds.pull-list.net"
];
var ENFORCE_ALLOWLIST = process.env.ENFORCE_DOMAIN_ALLOWLIST !== "false";
function addDomainToAllowlist(domain) {
  domain = domain.toLowerCase().trim();
  if (ALLOWED_DOMAINS.includes(domain)) {
    console.log(`Domain already in allowlist: ${domain}`);
    return false;
  }
  ALLOWED_DOMAINS.push(domain);
  console.log(`Added ${domain} to allowlist. Current list has ${ALLOWED_DOMAINS.length} domains.`);
  return true;
}
function getAllowedDomains() {
  return [...ALLOWED_DOMAINS];
}
function isIPv4Format(address) {
  const ipv4Regex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  if (!ipv4Regex.test(address))
    return false;
  const octets = address.split(".").map(Number);
  return octets.every((octet) => octet >= 0 && octet <= 255);
}
function isIPv6Format(address) {
  const ipv6Regex = /^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$/;
  return ipv6Regex.test(address);
}
function isValidUrl(urlString) {
  try {
    if (hasDangerousScheme(urlString)) {
      console.log(`Rejected dangerous URL scheme: ${urlString}`);
      return false;
    }
    if (!/^https?:\/\//i.test(urlString)) {
      urlString = "https://" + urlString;
    } else if (/^http:\/\//i.test(urlString)) {
      urlString = urlString.replace(/^http:/i, "https:");
    }
    if (hasDangerousScheme(urlString)) {
      console.log(`Rejected dangerous URL scheme: ${urlString}`);
      return false;
    }
    const url = new URL(urlString);
    if (url.protocol !== "https:") {
      console.log(`Rejected non-HTTPS URL: ${urlString}`);
      return false;
    }
    if (ENFORCE_ALLOWLIST && !isAllowedDomain(url.hostname)) {
      console.warn(`Domain not in allowlist: ${url.hostname}`);
      return false;
    }
    const pathname = url.pathname;
    if (pathname.includes("../") || pathname.includes("/..")) {
      console.warn(`Path traversal detected in URL path: ${pathname}`);
      return false;
    }
    return true;
  } catch (err) {
    return false;
  }
}
function isAllowedDomain(domain) {
  if (!ENFORCE_ALLOWLIST)
    return true;
  if (ALLOWED_DOMAINS.length === 0)
    return true;
  domain = domain.toLowerCase().trim();
  if (ALLOWED_DOMAINS.includes(domain)) {
    console.log(`Domain '${domain}' found in allowlist (exact match)`);
    return true;
  }
  const matchedWildcard = ALLOWED_DOMAINS.find((allowedDomain) => {
    if (allowedDomain.startsWith("*.")) {
      const baseDomain = allowedDomain.substring(2);
      const parts = domain.split(".");
      if (parts.length < 2)
        return false;
      const domainWithoutFirstSubdomain = parts.slice(1).join(".");
      const matches = domainWithoutFirstSubdomain === baseDomain;
      if (matches)
        console.log(`Domain '${domain}' matches wildcard '${allowedDomain}'`);
      return matches;
    }
    return false;
  });
  return !!matchedWildcard;
}
function validateIPAddress(address) {
  if (!address)
    return false;
  let normalizedAddr;
  try {
    if (isIPv4Format(address)) {
      try {
        const buffer = ip.toBuffer(address);
        normalizedAddr = ip.toString(buffer);
      } catch (e) {
        normalizedAddr = address;
      }
    } else if (isIPv6Format(address)) {
      normalizedAddr = address;
    } else {
      return false;
    }
  } catch (e) {
    return false;
  }
  if (normalizedAddr === "127.0.0.1" || normalizedAddr.startsWith("127.") || normalizedAddr === "::1" || normalizedAddr.toLowerCase().includes("127.0.0.1") || normalizedAddr.toLowerCase().includes("::1")) {
    return false;
  }
  try {
    return ip.isPublic(normalizedAddr);
  } catch (e) {
    return !isPrivateIP(normalizedAddr);
  }
}
function validateUrl(url) {
  try {
    console.log(`validateUrl - Checking URL: ${url}`);
    if (hasDangerousScheme(url)) {
      console.log(`Rejected dangerous URL scheme in validateUrl: ${url}`);
      return false;
    }
    const urlObj = new URL(url);
    const protocol = urlObj.protocol.toLowerCase();
    console.log(`validateUrl - Protocol detected: ${protocol}`);
    if (protocol !== "https:") {
      console.log(`Rejected non-HTTPS URL in validateUrl: ${url}`);
      return false;
    }
    const hostname = urlObj.hostname;
    console.log(`validateUrl - Hostname: ${hostname}`);
    if (ENFORCE_ALLOWLIST && !isAllowedDomain(hostname)) {
      console.warn(`Domain not in allowlist: ${hostname}`);
      return false;
    }
    console.log(`validateUrl - Domain allowlist check passed`);
    if (isIPv4Format(hostname) || isIPv6Format(hostname)) {
      console.log(`validateUrl - Hostname is an IP address: ${hostname}`);
      const ipValid = validateIPAddress(hostname);
      console.log(`validateUrl - IP validation result: ${ipValid}`);
      return ipValid;
    }
    console.log(`validateUrl - Validation successful for: ${url}`);
    return true;
  } catch (e) {
    console.error(`validateUrl - Error validating URL: ${e}`);
    return false;
  }
}
function isPrivateIP(ipStr) {
  const privateRanges = [
    "10.0.0.0/8",
    "172.16.0.0/12",
    "192.168.0.0/16",
    "127.0.0.0/8",
    "169.254.0.0/16"
  ];
  return privateRanges.some((range) => {
    try {
      const cidr = new IPCIDR(range);
      return cidr.contains(ipStr);
    } catch (error) {
      console.error(`Error checking IP range ${range}:`, error);
      return false;
    }
  });
}
var hasValidOpenAIKey = (env) => !!env.OPENAI_API_KEY && ("" + env.OPENAI_API_KEY).startsWith("sk-");
async function getGPTRecommendation(checkType, keyphrase, env, context) {
  const useGPT = env.USE_GPT_RECOMMENDATIONS !== "false";
  if (!useGPT || !hasValidOpenAIKey(env)) {
    console.log("GPT recommendations are disabled or API key is invalid");
    return "GPT recommendations are currently disabled. Enable them by setting USE_GPT_RECOMMENDATIONS=true and providing a valid OPENAI_API_KEY.";
  }
  const client = new OpenAI({ apiKey: env.OPENAI_API_KEY });
  try {
    const cacheKey = `${checkType}_${keyphrase}_${context?.substring(0, 50) || ""}`;
    const truncatedContext = context && context.length > 300 ? context.substring(0, 300) + "..." : context;
    const response = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are an SEO expert providing concise, actionable recommendations.
Keep responses under 100 words.
Format: "Here is a better [element]: [example]"
Avoid quotation marks.`
        },
        {
          role: "user",
          content: `Fix this SEO issue: "${checkType}" for keyphrase "${keyphrase}".
${truncatedContext ? `Current content: ${truncatedContext}` : ""}`
        }
      ],
      max_tokens: 100,
      temperature: 0.5
    });
    const recommendation = response.choices[0].message.content?.trim() || "Unable to generate recommendation at this time.";
    return recommendation;
  } catch (error) {
    console.error("GPT API Error:", error);
    if (error.status === 401) {
      return "API key error. Please check your OpenAI API key and ensure it's valid.";
    }
    return "Unable to generate recommendation. Please try again later.";
  }
}
var analyzerCheckPriorities = {
  "Keyphrase in Title": "high",
  "Keyphrase in Meta Description": "high",
  "Keyphrase in URL": "medium",
  "Content Length": "high",
  "Keyphrase Density": "medium",
  "Keyphrase in Introduction": "medium",
  "Image Alt Attributes": "low",
  "Internal Links": "medium",
  "Outbound Links": "low",
  "Next-Gen Image Formats": "low",
  "OG Image": "medium",
  "OG Title and Description": "medium",
  "Keyphrase in H1 Heading": "high",
  "Keyphrase in H2 Headings": "medium",
  "Heading Hierarchy": "high",
  "Code Minification": "low",
  "Schema Markup": "medium",
  "Image File Size": "medium"
};
var analyzerFallbackRecommendations = {
  "Keyphrase in Title": ({ keyphrase, title }) => `Consider rewriting your title to include '${keyphrase}', preferably at the beginning.`,
  "Keyphrase in Meta Description": ({ keyphrase }) => `Add '${keyphrase}' to your meta description naturally to boost click-through rates.`,
  "Keyphrase in Introduction": ({ keyphrase }) => `Mention '${keyphrase}' in your first paragraph to establish relevance early.`
  // ... add additional fallback recommendations as needed ...
};
async function analyzeSEOElements(url, keyphrase) {
  console.log(`[SEO Analyzer] Starting analysis for URL: ${url} with keyphrase: ${keyphrase}`);
  const startTime = Date.now();
  try {
    const scrapedData = await scrapeWebpage(url);
    const checks = [];
    let passedChecks = 0, failedChecks = 0;
    const messages = {
      "Keyphrase in Title": "Great job! Your title includes the target keyphrase."
      // ... add other success messages as needed ...
    };
    const addCheck = async (title, description, passed, context, skipRecommendation = false) => {
      let recommendation = "";
      if (!passed && !skipRecommendation) {
        try {
          recommendation = await getGPTRecommendation(title, keyphrase, context);
        } catch (error) {
          recommendation = analyzerFallbackRecommendations[title] ? analyzerFallbackRecommendations[title]({ keyphrase }) : `Consider optimizing your content for "${keyphrase}" in relation to ${title.toLowerCase()}.`;
        }
      }
      const successDescription = passed ? messages[title] : description;
      const priority = analyzerCheckPriorities[title] || "medium";
      checks.push({ title, description: successDescription, passed, recommendation, priority });
      passed ? passedChecks++ : failedChecks++;
    };
    await addCheck(
      "Keyphrase in Title",
      "The page title should contain the focus keyphrase.",
      scrapedData.title.toLowerCase().includes(keyphrase.toLowerCase()),
      scrapedData.title
    );
    const score = Math.round(passedChecks / checks.length * 100);
    console.log(`[SEO Analyzer] Analysis completed in ${Date.now() - startTime}ms`);
    return { checks, passedChecks, failedChecks, url, score, timestamp: (/* @__PURE__ */ new Date()).toISOString() };
  } catch (error) {
    console.error(`[SEO Analyzer] Error during analysis:`, error);
    throw error;
  }
}
async function getImageSize(imageUrl, baseUrl) {
  try {
    const fullUrl = new URL(imageUrl, baseUrl.origin).toString();
    const response = await fetch(fullUrl, { method: "HEAD" });
    if (response.ok) {
      const contentLength = response.headers.get("content-length");
      if (contentLength) {
        return parseInt(contentLength, 10);
      }
    }
    return void 0;
  } catch (error) {
    console.log(`Error getting size for image ${imageUrl}:`, error);
    return void 0;
  }
}
async function scrapeWebpageJS(url) {
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    url = `http://${url}`;
  }
  try {
    const response = await fetch(url);
    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;
    const baseUrl = new URL(url);
    const title = document.querySelector("title")?.textContent?.trim() || "";
    const metaDescription = document.querySelector('meta[name="description"]')?.getAttribute("content") || "";
    const ogMetadata = {
      title: document.querySelector('meta[property="og:title"]')?.getAttribute("content") || "",
      description: document.querySelector('meta[property="og:description"]')?.getAttribute("content") || "",
      image: document.querySelector('meta[property="og:image"]')?.getAttribute("content") || "",
      imageWidth: document.querySelector('meta[property="og:image:width"]')?.getAttribute("content") || "",
      imageHeight: document.querySelector('meta[property="og:image:height"]')?.getAttribute("content") || ""
    };
    const content = document.body.textContent?.trim() || "";
    console.log("Scraping paragraphs...");
    const allParagraphElements = document.querySelectorAll("article p, main p, .content p, #content p, .post-content p, p");
    const paragraphs = Array.from(allParagraphElements).map((el) => el.textContent?.trim() || "").filter((text) => text.length > 0);
    const subheadings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6")).map((el) => el.textContent?.trim() || "").filter((text) => text.length > 0);
    const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6")).map((el) => {
      const tagName = el.tagName.toLowerCase();
      const level = parseInt(tagName.substring(1), 10);
      return { level, text: el.textContent?.trim() || "" };
    }).filter((heading) => heading.text.length > 0);
    const imageElements = Array.from(document.querySelectorAll("img")).map((el) => ({
      src: el.getAttribute("src") || "",
      alt: el.getAttribute("alt") || ""
    }));
    const images = await Promise.all(
      imageElements.map(async (img) => {
        if (!img.src)
          return img;
        const size = await getImageSize(img.src, baseUrl);
        return { ...img, size };
      })
    );
    const internalLinks = [];
    const outboundLinks = [];
    document.querySelectorAll("a[href]").forEach((el) => {
      const href = el.getAttribute("href");
      if (!href)
        return;
      try {
        const linkUrl = new URL(href, baseUrl.origin);
        if (linkUrl.hostname === baseUrl.hostname) {
          internalLinks.push(href);
        } else {
          outboundLinks.push(href);
        }
      } catch (error) {
      }
    });
    const jsResources = [];
    const cssResources = [];
    document.querySelectorAll("script[src]").forEach((el) => {
      const src = el.getAttribute("src");
      if (src) {
        try {
          const fullUrl = new URL(src, baseUrl.origin).toString();
          jsResources.push({ url: fullUrl });
        } catch (error) {
        }
      }
    });
    document.querySelectorAll("link[rel='stylesheet']").forEach((el) => {
      const href = el.getAttribute("href");
      if (href) {
        try {
          const fullUrl = new URL(href, baseUrl.origin).toString();
          cssResources.push({ url: fullUrl });
        } catch (error) {
        }
      }
    });
    document.querySelectorAll("style").forEach((el) => {
      const content2 = el.textContent;
      if (content2 && content2.trim()) {
        cssResources.push({
          url: "inline-style",
          content: content2.trim(),
          minified: isMinified(content2.trim())
        });
      }
    });
    document.querySelectorAll("script:not([src])").forEach((el) => {
      const content2 = el.textContent;
      if (content2 && content2.trim()) {
        jsResources.push({
          url: "inline-script",
          content: content2.trim(),
          minified: isMinified(content2.trim())
        });
      }
    });
    const jsonLdBlocks = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach((el) => {
      try {
        const jsonContent = el.textContent;
        if (jsonContent) {
          const parsed = JSON.parse(jsonContent);
          jsonLdBlocks.push(parsed);
        }
      } catch (error) {
        console.log("Error parsing JSON-LD:", error);
      }
    });
    const microdataTypes = [];
    document.querySelectorAll("[itemscope]").forEach((el) => {
      const itemtype = el.getAttribute("itemtype");
      if (itemtype) {
        try {
          const match = itemtype.match(/schema\.org\/([a-zA-Z]+)/);
          if (match && match[1]) {
            microdataTypes.push(match[1]);
          } else {
            microdataTypes.push(itemtype);
          }
        } catch (error) {
          console.log("Error extracting microdata type:", error);
        }
      }
    });
    const schemaTypes = /* @__PURE__ */ new Set();
    jsonLdBlocks.forEach((block) => {
      if (block["@type"]) {
        if (Array.isArray(block["@type"])) {
          block["@type"].forEach((type) => schemaTypes.add(type));
        } else {
          schemaTypes.add(block["@type"]);
        }
      }
    });
    microdataTypes.forEach((type) => schemaTypes.add(type));
    return {
      title,
      metaDescription,
      content,
      paragraphs,
      subheadings,
      headings,
      images,
      internalLinks,
      outboundLinks,
      ogMetadata,
      resources: { js: jsResources, css: cssResources },
      schema: { detected: jsonLdBlocks.length > 0 || microdataTypes.length > 0, types: Array.from(schemaTypes), jsonLdBlocks, microdataTypes }
    };
  } catch (error) {
    console.error("Failed to scrape webpage:", error);
    throw new Error(`Failed to scrape webpage: ${error.message}`);
  }
}
function isMinified(code) {
  if (!code || code.length < 50)
    return true;
  const newlineRatio = (code.match(/\n/g) || []).length / code.length;
  const whitespaceRatio = (code.match(/\s/g) || []).length / code.length;
  const lines = code.split("\n").filter((line) => line.trim().length > 0);
  const avgLineLength = lines.length > 0 ? code.length / lines.length : 0;
  return newlineRatio < 0.01 && whitespaceRatio < 0.15 || avgLineLength > 500;
}
async function analyzeSEO(url, keyphrase, env) {
  console.log(`Starting SEO analysis for ${url} with keyphrase "${keyphrase}"`);
  try {
    const scrapedData = await scrapeWebpage(url);
    const checks = [];
    let passedChecks = 0;
    let failedChecks = 0;
    const addCheck = async (title, description, passed, context, skipRecommendation = false) => {
      let recommendation = "";
      if (!passed && !skipRecommendation) {
        try {
          recommendation = await getGPTRecommendation(title, keyphrase, env, context);
        } catch (error) {
          console.error(`Error getting GPT recommendation for ${title}:`, error);
          recommendation = fallbackRecommendations[title] ? fallbackRecommendations[title](keyphrase, context || "") : `Consider optimizing your content for "${keyphrase}" in relation to ${title.toLowerCase()}.`;
        }
      }
      const successMessage = passed ? getSuccessMessage(title, url) : description;
      const priority = checkPriorities[title] || "medium";
      checks.push({
        title,
        description: successMessage,
        passed,
        recommendation,
        priority
      });
      passed ? passedChecks++ : failedChecks++;
    };
    await addCheck(
      "Keyphrase in Title",
      "Your title doesn't contain the keyphrase.",
      scrapedData.title.toLowerCase().includes(keyphrase.toLowerCase()),
      scrapedData.title
    );
    await addCheck(
      "Keyphrase in Meta Description",
      "Your meta description doesn't contain the keyphrase.",
      scrapedData.metaDescription.toLowerCase().includes(keyphrase.toLowerCase()),
      scrapedData.metaDescription
    );
    const urlObj = new URL(url);
    await addCheck(
      "Keyphrase in URL",
      "Your URL doesn't contain the keyphrase.",
      isHomePage(url) || urlObj.pathname.toLowerCase().includes(keyphrase.toLowerCase().replace(/\s+/g, "-")),
      urlObj.pathname
    );
    const contentLength = scrapedData.content.length;
    await addCheck(
      "Content Length on page",
      "Your content is too short. Aim for at least 300 words.",
      contentLength >= 300,
      `Current content length: ${contentLength} characters`
    );
    const { density, occurrences, totalWords } = calculateKeyphraseDensity(scrapedData.content, keyphrase);
    await addCheck(
      "Keyphrase Density",
      `Your keyphrase density of ${density.toFixed(1)}% is outside the optimal range (0.5% to 2.5%).`,
      density >= 0.5 && density <= 2.5,
      `Current density: ${density.toFixed(1)}% (${occurrences} occurrences in ${totalWords} words)`
    );
    const hasIntroduction = scrapedData.paragraphs.length > 0;
    const introductionText = hasIntroduction ? scrapedData.paragraphs[0] : "";
    await addCheck(
      "Keyphrase in Introduction",
      "Your introduction doesn't contain the keyphrase.",
      hasIntroduction && introductionText.toLowerCase().includes(keyphrase.toLowerCase()),
      introductionText
    );
    const h1Headings = scrapedData.headings.filter((h) => h.level === 1);
    const hasH1WithKeyphrase = h1Headings.some((h) => h.text.toLowerCase().includes(keyphrase.toLowerCase()));
    await addCheck(
      "Keyphrase in H1 Heading",
      h1Headings.length === 0 ? "Your page has no H1 heading." : "Your H1 heading doesn't contain the keyphrase.",
      hasH1WithKeyphrase,
      h1Headings.map((h) => h.text).join(", ")
    );
    const h2Headings = scrapedData.headings.filter((h) => h.level === 2);
    const hasH2WithKeyphrase = h2Headings.some((h) => h.text.toLowerCase().includes(keyphrase.toLowerCase()));
    await addCheck(
      "Keyphrase in H2 Headings",
      h2Headings.length === 0 ? "Your page has no H2 headings." : "None of your H2 headings contain the keyphrase.",
      hasH2WithKeyphrase,
      h2Headings.map((h) => h.text).join(", ")
    );
    const hasProperHierarchy = h1Headings.length === 1 && scrapedData.headings.every(
      (h, i, arr) => i === 0 || h.level >= arr[i - 1].level || h.level === arr[i - 1].level + 1
    );
    await addCheck(
      "Heading Hierarchy",
      "Your page doesn't have proper heading hierarchy. Use exactly one H1 and nest headings properly.",
      hasProperHierarchy
    );
    const imagesWithAlt = scrapedData.images.filter((img) => img.alt && img.alt.trim() !== "");
    const imagesWithKeyphraseInAlt = scrapedData.images.filter(
      (img) => img.alt && img.alt.toLowerCase().includes(keyphrase.toLowerCase())
    );
    await addCheck(
      "Image Alt Attributes",
      scrapedData.images.length === 0 ? "Your page has no images." : imagesWithAlt.length === 0 ? "None of your images have alt attributes." : "None of your image alt attributes contain the keyphrase.",
      imagesWithKeyphraseInAlt.length > 0,
      imagesWithAlt.map((img) => img.alt).join(", ")
    );
    await addCheck(
      "Internal Links",
      "Your page has no internal links.",
      scrapedData.internalLinks.length > 0,
      `Current internal links: ${scrapedData.internalLinks.length}`
    );
    await addCheck(
      "Outbound Links",
      "Your page has no outbound links to authoritative sources.",
      scrapedData.outboundLinks.length > 0,
      `Current outbound links: ${scrapedData.outboundLinks.length}`
    );
    const nextGenImages = scrapedData.images.filter((img) => isNextGenImageFormat(img.src));
    await addCheck(
      "Next-Gen Image Formats",
      "None of your images use next-gen formats like WebP, AVIF, or JPEG 2000.",
      nextGenImages.length > 0 || scrapedData.images.length === 0,
      `${nextGenImages.length} of ${scrapedData.images.length} images use next-gen formats`
    );
    await addCheck(
      "OpenGraph Image",
      "Your page is missing an OpenGraph image for social sharing.",
      !!scrapedData.ogMetadata.image,
      scrapedData.ogMetadata.image
    );
    await addCheck(
      "Open Graph Title and Description",
      "Your page is missing OpenGraph title and description for social sharing.",
      !!scrapedData.ogMetadata.title && !!scrapedData.ogMetadata.description,
      `OG Title: ${scrapedData.ogMetadata.title}, OG Description: ${scrapedData.ogMetadata.description}`
    );
    const minifiedJs = scrapedData.resources.js.filter((js) => js.minified).length;
    const minifiedCss = scrapedData.resources.css.filter((css) => css.minified).length;
    const allResourcesMinified = (minifiedJs === scrapedData.resources.js.length || scrapedData.resources.js.length === 0) && (minifiedCss === scrapedData.resources.css.length || scrapedData.resources.css.length === 0);
    await addCheck(
      "Code Minification",
      "Your JavaScript and/or CSS files are not minified.",
      allResourcesMinified,
      `Minified JS: ${minifiedJs}/${scrapedData.resources.js.length}, Minified CSS: ${minifiedCss}/${scrapedData.resources.css.length}`
    );
    await addCheck(
      "Schema Markup",
      "Your page doesn't include schema.org structured data.",
      scrapedData.schema.detected,
      scrapedData.schema.types.length > 0 ? `Schema types: ${scrapedData.schema.types.join(", ")}` : "No schema types detected"
    );
    const largeImages = scrapedData.images.filter((img) => img.size && img.size > 2e5);
    await addCheck(
      "Image File Size",
      largeImages.length > 0 ? "Some of your images are too large (>200KB)." : "Your images are well optimized.",
      largeImages.length === 0,
      `${largeImages.length} of ${scrapedData.images.length} images are too large`
    );
    const score = Math.round(passedChecks / checks.length * 100);
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    console.log(`Completed SEO analysis with score: ${score}%`);
    return {
      checks,
      passedChecks,
      failedChecks,
      score,
      url,
      keyphrase,
      timestamp
    };
  } catch (error) {
    console.error("Error analyzing SEO:", error);
    throw new Error(`Failed to analyze SEO: ${error.message}`);
  }
}
var workers_default = { fetch: handleRequest };
export {
  addDomainToAllowlist,
  analyzeSEOElements,
  workers_default as default,
  getAllowedDomains,
  getGPTRecommendation,
  isAllowedDomain,
  isPrivateIP,
  isValidUrl,
  scrapeWebpageJS,
  validateIPAddress,
  validateUrl
};
